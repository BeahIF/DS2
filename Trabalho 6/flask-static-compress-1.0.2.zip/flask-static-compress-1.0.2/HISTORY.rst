
History
-------


1.0.2 (2017-10-22)
++++++++++++++++++

- Require jac v0.16.3 or newer to follow custom compressor example.


1.0.1 (2017-08-27)
++++++++++++++++++

- Upgrade jac to v0.16.1 to fix default compressor output path.


1.0.0 (2016-12-15)
++++++++++++++++++

- Birth.
