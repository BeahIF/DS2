# -*- coding: utf-8 -*-
"""
    Flask-Static-Compress
    ~~~~~~~~~~~~~~~~~~~~~
    :copyright: (c) 2016 Alan Hamlett.
    :license: BSD, see LICENSE for more details.
"""


from jac.contrib.flask import JAC as FlaskStaticCompress
